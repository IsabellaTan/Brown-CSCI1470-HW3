import wandb

wandb.login()